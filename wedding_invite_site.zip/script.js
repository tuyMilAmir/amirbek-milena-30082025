function switchLang(lang) {
  if (lang === 'ru') {
    document.documentElement.lang = 'ru';
    document.querySelector('h1').innerText = 'Амирбек & Милена';
    document.querySelector('.date').innerText = '30 августа 2025 в 18:00';
    document.querySelector('.tagline').innerText = 'Однажды — это уже 30 августа. Мы сказали «Да» любви и приглашаем вас разделить это счастье с нами.';
    document.querySelector('button[type=submit]').innerText = 'Подтвердить участие';
  } else {
    document.documentElement.lang = 'uz';
    document.querySelector('h1').innerText = 'Amirbek & Milena';
    document.querySelector('.date').innerText = '2025-yil 30-avgust, 18:00';
    document.querySelector('.tagline').innerText = '30-avgust — bu bizning muhabbatimiz tantanasi. Sizni biz bilan birga nishonlashga taklif qilamiz.';
    document.querySelector('button[type=submit]').innerText = 'Ishtirokni tasdiqlash';
  }
}
